import tkinter as tk
from PIL import ImageTk, Image

# Créer une instance de la classe Tk
root = tk.Tk()

# Définir le titre de la fenêtre
root.title("Page d'accueil")

# Créer un label pour le titre de la page d'accueil
title_label = tk.Label(root, text="Bienvenue sur la page d'accueil", font=("Helvetica", 20))
title_label.pack(pady=20)

# Ajouter une image à la page d'accueil
image = Image.open("example.png")
photo = ImageTk.PhotoImage(image)
image_label = tk.Label(root, image=photo)
image_label.pack(pady=10)

# Créer un bouton pour quitter l'application
quit_button = tk.Button(root, text="Quitter", command=root.destroy)
quit_button.pack(pady=10)

# Lancer la boucle principale Tkinter
root.mainloop()
