import io
from PIL import Image
with open("C:\\Users\\pc\\Desktop\\ID1 (chad)\\stats 2 (blowed)\\data-image (2).bin", "rb") as file:
    content= file.read()
print (content)
img = Image.frombytes("RGB", (1000, 1000), content)
img.show()