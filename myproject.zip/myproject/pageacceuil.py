import tkinter as tk
from tkinter import *

import ImageTk

root=Tk()
root.geometry('990x660+50+50')
root.title('Ensah')
bg = PhotoImage(file="C:/Users/pc/Downloads/ensahn.png")
label1 = Label(root, image=bg)
label1.place(x=985,y=753)


def home_page():
    home_frame=tk.Frame(main_frame)
    lb=tk.Label(home_frame,text='Home page\n\nPage : 1',font=('Bold',30))
    lb.pack()
    home_frame.pack(pady=20)

def menu_page():
    menu_frame=tk.Frame(main_frame)
    lb=tk.Label(menu_frame,text='Home page\n\nPage : 2',font=('Bold',30))
    lb.pack()
    menu_frame.pack(pady=20)

def contact_page():
    contact_frame=tk.Frame(main_frame)
    lb1 = tk.Label(contact_frame, text='Ecole Nationale des Sciences Appliquées \nd Al Hoceima \n',font=('Bold',30))
    lb=tk.Label(contact_frame,text='BP 03, Ajdir Al-Hoceima,\n'
                                   'Tel: +212(0) 539 80 57 12 \n'
                                   'Fax: +212(0) 539 80 57 13',font=('Bold',20))
    lb1.pack()
    lb.pack()
    contact_frame.pack(pady=20)

def formation_page():
    formation_frame=tk.Frame(main_frame)
    lb=tk.Label(formation_frame,text='formation page\n\nPage : 4',font=('Bold',30))
    lb.pack()
    formation_frame.pack(pady=20)

def a_propos_page():
    a_propos_frame=tk.Frame(main_frame)
    lb=tk.Label(a_propos_frame,text='formation page\n\nPage : 4',font=('Bold',30))
    lb.pack()
    a_propos_frame.pack(pady=20)

def service_en_ligne_page():
    service_en_ligne_frame=tk.Frame(main_frame)
    lb=tk.Label(service_en_ligne_frame,text='service_en_ligne page\n\nPage : 4',font=('Bold',30))
    lb.pack()
    service_en_ligne_frame.pack(pady=20)

def hide_indicators():
    home_indicate.config(bg='white')
    #menu_indicate.config(bg='white')
    contact_indicate.config(bg='white')
    formation_indicate.config(bg='white')
    sevice_en_ligne_indicate.config(bg='white')
    a_propos_indicate.config(bg='white')

def delete_pages():
    for frame in main_frame.winfo_children():
        frame.destroy()

def indicate(lb,page):
    hide_indicators()
    lb.config(bg='#158aff')
    delete_pages()
    page()

options_frame=tk.Frame(root,bg='#158aff')

head_frame=tk.Frame(root,bg='#158aff',highlightthickness=1)
head_frame.pack(side=tk.TOP,fill=tk.X)
head_frame.pack_propagate(False)
head_frame.configure(height=50)

home_btn=tk.Button(options_frame,text='HOME',font=('Bold',15),fg='white',bd=0,bg='#158aff',command=lambda :indicate(home_indicate,home_page))
home_btn.place(x=35,y=50)
home_indicate=tk.Label(options_frame, text='',bg='#158aff')
home_indicate.place(x=3,y=50,width=5,height=40)


a_propos_btn=tk.Button(options_frame,text='MENU',font=('Bold',15),fg='white',bd=0,bg='#158aff',command=lambda :indicate(a_propos_indicate,a_propos_page))
a_propos_btn.place(x=35,y=250)
a_propos_indicate=tk.Label(options_frame, text='',bg='#158aff')
a_propos_indicate.place(x=3,y=250,width=5,height=40)

contact_btn=tk.Button(options_frame,text='CONTACT',font=('Bold',15),fg='white',bd=0,bg='#158aff',command=lambda :indicate(contact_indicate,contact_page))
contact_btn.place(x=35,y=200)
contact_indicate=tk.Label(options_frame, text='',bg='#158aff')
contact_indicate.place(x=3,y=200,width=5,height=40)

formation_btn=tk.Button(options_frame,text='FORMATION',font=('Bold',15),fg='white',bd=0,bg='#158aff',command=lambda :indicate(formation_indicate,formation_page))
formation_btn.place(x=35,y=100)
formation_indicate=tk.Label(options_frame, text='',bg='#158aff')
formation_indicate.place(x=3,y=100,width=5,height=40)

sevice_en_ligne_btn=tk.Button(options_frame,text='Service en ligne',font=('Bold',15),fg='white',bd=0,bg='#158aff',command=lambda :indicate(sevice_en_ligne_indicate,service_en_ligne_page))
sevice_en_ligne_btn.place(x=35,y=150)
sevice_en_ligne_indicate=tk.Label(options_frame, text='',bg='#158aff')
sevice_en_ligne_indicate.place(x=3,y=150,width=5,height=40)


options_frame.pack(side=tk.LEFT)
options_frame.pack_propagate(False)
options_frame.configure(width=200,height=1000)

main_frame=tk.Frame(root,highlightbackground='black',highlightthickness=1)

main_frame.pack(side=tk.LEFT)
main_frame.pack_propagate(False)
main_frame.configure(height=1000,width=1400)
#guii





root.mainloop()